#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2020/12/21 上午 08:12
#@Author: SGK
#@File  : video_detct.py

from PIL import ImageFont, ImageDraw, Image
from video.sn import snow_check,strip
from video.loopIP import *
import argparse
import numpy as np
import math
import cv2
import os
import re
import time

#blurry：模糊；black：黑屏；strip：条纹；snow：雪花----阈值
ap = argparse.ArgumentParser()
ap.add_argument("-blu", "--bludata", type=float, default=1400.000,help="blurry")#小于(模糊参数)
ap.add_argument("-bla", "--bladata", type=float, default=0.850,help="black")#大于等于（黑屏参数）
ap.add_argument("-str", "--strdata", type=float, default=0.004,help="strip")#小于等于（条纹参数）
ap.add_argument("-sno", "--snodata", type=float, default=0.400,help="snow")#大于等于（雪花参数）
ap.add_argument("-ocd", "--ocddata", type=float, default=30.000,help="occlud")#小于（遮挡参数）
args = vars(ap.parse_args())

T = 50  # 阈值设定，大于T则判定偏离xy轴过多
T1 = 100  # 阈值1，通道行差
T2 = 1000  # 阈值2，A通道差绝对和
T3 = 1000  # 阈值3，AB通道绝对和
# 复数类
class complex:
    def __init__(self):
        self.real = 0.0
        self.image = 0.0
# 复数乘法
def mul_ee(complex0, complex1):
    complex_ret = complex()
    complex_ret.real = complex0.real * complex1.real - complex0.image * complex1.image
    complex_ret.image = complex0.real * complex1.image + complex0.image * complex1.real
    return complex_ret

# 复数加法
def add_ee(complex0, complex1):
    complex_ret = complex()
    complex_ret.real = complex0.real + complex1.real
    complex_ret.image = complex0.image + complex1.image
    return complex_ret

# 复数减法
def sub_ee(complex0, complex1):
    complex_ret = complex()
    complex_ret.real = complex0.real - complex1.real
    complex_ret.image = complex0.image - complex1.image
    return complex_ret

# 对输入数据进行倒序排列
def forward_input_data(input_data, num):
    j = num // 2
    for i in range(1, num - 2):
        if (i < j):
            complex_tmp = input_data[i]
            input_data[i] = input_data[j]
            input_data[j] = complex_tmp
            # print "forward x[%d] <==> x[%d]" % (i, j)
        k = num // 2
        while (j >= k):
            j = j - k
            k = k // 2
        j = j + k

# 实现1D FFT
def fft_1d(in_data, num):
    PI = 3.1415926
    forward_input_data(in_data, num)  # 倒序输入数据

    # 计算蝶形级数，也就是迭代次数
    M = 1  # num = 2^m
    tmp = num // 2;
    while (tmp != 1):
        M = M + 1
        tmp = tmp // 2
    # print "FFT level：%d" % M

    complex_ret = complex()
    for L in range(1, M + 1):
        B = int(math.pow(2, L - 1))  # B为指数函数返回值，为float，需要转换integer
        for J in range(0, B):
            P = math.pow(2, M - L) * J
            for K in range(J, num, int(math.pow(2, L))):
                # print "L:%d B:%d, J:%d, K:%d, P:%f" % (L, B, J, K, P)
                complex_ret.real = math.cos((2 * PI / num) * P)
                complex_ret.image = -math.sin((2 * PI / num) * P)
                complex_mul = mul_ee(complex_ret, in_data[K + B])
                complex_add = add_ee(in_data[K], complex_mul)
                complex_sub = sub_ee(in_data[K], complex_mul)
                in_data[K] = complex_add
                in_data[K + B] = complex_sub
                # print "A[%d] real: %f, image: %f" % (K, in_data[K].real, in_data[K].image)
                # print "A[%d] real: %f, image: %f" % (K + B, in_data[K + B].real, in_data[K + B].image)

def main_fft_1d(in_data):
    # in_data = [2,3,4,5,7,9,10,11,100,12,14,11,56,12,67,12] #待测试的x点元素
    k = 1
    while (1):
        if len(in_data) > pow(2, k) and len(in_data) <= pow(2, k + 1):  # 不足的补0
            # fftlen=pow(2,k+1)
            # in_data.extend([0 for i in range(pow(2,k+1)-len(in_data))])
            fftlen = pow(2, k)
            break
        k += 1
    # 变量data为长度为x、元素为complex类实例的list，用于存储输入数据
    data = [(complex()) for i in range(len(in_data))]
    # 将8个测试点转换为complex类的形式，存储在变量data中
    for i in range(len(in_data)):
        data[i].real = in_data[i]
        data[i].image = 0.0

    ##输出FFT需要处理的数据
    # print("The input data:")
    # for i in range(len(in_data)):
    #    print("x[%d] real: %f, image: %f" % (i, data[i].real, data[i].image))

    fft_1d(data, fftlen)

    ##输出经过FFT处理后的结果
    # print("The output data:")
    # for i in range(len(in_data)):
    # print("X[%d] real: %f, image: %f" % (i, data[i].real, data[i].image))

    Tnum = 0
    for i in range(len(in_data)):  # 虚实值都大于T的才叫偏离
        if abs(data[i].real) > T and abs(data[i].image) > T:
            Tnum += 1
    #print(Tnum)
    res=round(Tnum / len(in_data), 5)
    print(str(round(Tnum / len(in_data), 4) * 100) + "%")
    return res

#***********************雪花检测/无信号***********************
def snow_fft(img):
    im = np.array(img.convert('L'))  # 灰度化矩阵
    in_data = []
    for item in im:
        in_data.extend(item)
    res=main_fft_1d(in_data)
    return res

def snow_axi(im):
    height = im.shape[0]  # 尺寸
    width = im.shape[1]
    varlist = []
    for i in range(height):
        for j in range(width):
            for k in range(16):
                if im[i][j] >= k * 16 and im[i][j] < (k + 1) * 16:  # 16级量化
                    im[i][j] = 8 * (k * 2 + 1)
                    break
    for i in range(0, height - height % 3, 3):
        for j in range(0, width - width % 3, 3):
            x = (im[i][j] + im[i + 1][j] + im[i + 2][j] + im[i][j + 1] + im[i + 1][j + 1] + im[i + 2][j + 1] + im[i][
                j + 2] + im[i + 1][j + 2] + im[i + 2][j + 2]) / 9
            x2 = (pow(im[i][j], 2) + pow(im[i + 1][j], 2) + pow(im[i + 2][j], 2) + pow(im[i][j + 1], 2) + pow(
                im[i + 1][j + 1], 2) + pow(im[i + 2][j + 1], 2) + pow(im[i][j + 2], 2) + pow(im[i + 1][j + 2], 2) + pow(
                im[i + 2][j + 2], 2)) / 9
            var = x2 - pow(x, 2)
            varlist.append(round(var, 3))  # 子窗口的方差值3x3
    #print(im)
    # print(varlist)
    res = round(sum(varlist) / len(varlist), 3)  # 保留3位小数
    print(res)
    return res

#***********************条纹检测/信号干扰***********************
def stripe(img):
    im=np.array(img.convert('L'))#灰度化矩阵
    r,g,b=img.split()
    #gm=demo.convert('L')
    #plt.subplot(2,2,1)
    #plt.imshow(gm,cmap='gray'),plt.axis('off')
    #plt.subplot(2,2,2)
    #plt.imshow(r,cmap='gray'),plt.axis('off')
    #plt.subplot(2,2,3)
    #plt.imshow(g,cmap='gray'),plt.axis('off')
    #plt.subplot(2,2,4)
    #plt.imshow(b,cmap='gray'),plt.axis('off')
    #plt.show()
    rm=np.array(r)
    gm=np.array(g)
    bm=np.array(b)
    height=im.shape[0]#尺寸
    width=im.shape[1]
    midimg=[im,rm,gm,bm]
    count=0
    for i in range(4):
        mid=midimg[i]
        n=0
        while(1):
            if n+3>=height:break
            for j in range(6,width-6,1):
                grA=mid[n][j]
                grB=mid[n+3][j]
                if abs(grA-grB)>T1:
                    L1=0
                    L2=0
                    for k in range(j-6,j+6,1):
                        L1+=abs(mid[n][k]-grA)
                        L2+=abs(mid[n][k]-mid[n+3][k])
                        #print(L1)
                        #print(L2)
                        #print("-----")
                        if L1<T2 and L2>T3:
                            count+=1
            n+=10
    sum=(height-3)*4*(width-12)
    #print(count/sum)
    res=round(count/sum,5)#保留3位小数
    #print(str(res*100)+"%")
    return res

#***********************黑屏检测/无信号***********************
def black(img,gray):
    #gray_lwpCV = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #gray_lwpCV = cv2.GaussianBlur(gray_lwpCV, (21, 21), 0)
    r, c = gray.shape[:2]
    piexs_sum = r * c  # 整个灰度图的像素个数为r*c
    # 获取偏暗的像素(表示0~19的灰度值为暗) 此处阈值可以修改
    dark_points = (gray < 20)
    target_array = gray[dark_points]
    #print(target_array)
    dark_sum = target_array.size
    # 判断灰度值为暗的百分比
    dark_prop = round(dark_sum / (piexs_sum),3)
    return dark_prop

def variance_of_laplacian(image):
    return cv2.Laplacian(image, cv2.CV_64F).var()

#***********************拉普拉斯--模糊检测***********************
def blur_lap(img,gray):
    fm = variance_of_laplacian(gray)
    return round(fm,3)
def SMD(img):
    img1 = cv2.copyMakeBorder(img, 0, 0, 1, 0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
    img2 = cv2.copyMakeBorder(img, 0, 0, 0, 1, cv2.BORDER_CONSTANT, value=[0, 0, 0])
    data0 = np.array((img1[:, :]), dtype=np.int)
    data00 = np.array((img2[:, :]), dtype=np.int)
    d = np.subtract(data0, data00)
    d1 = cv2.convertScaleAbs(d[1:-1, 1:-1])
    d2 = d1.flatten()
    j = d2.sum()
    img3 = cv2.copyMakeBorder(img, 1, 0, 0, 0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
    img4 = cv2.copyMakeBorder(img, 0, 1, 0, 0, cv2.BORDER_CONSTANT, value=[0, 0, 0])
    data1 = np.array((img3[:, :]), dtype=np.int)
    data2 = np.array((img4[:, :]), dtype=np.int)
    c = np.subtract(data1, data2)
    # c1=abs(c[1:-1, 1:-1].astype(np.uint8))
    c1 = cv2.convertScaleAbs(c[1:-1, 1:-1])
    c2 = c1.flatten()
    h = c2.sum()
    out = h + j
    return out

#***********************SMD-帧差法-模糊检测***********************
def blur(img,pre_frame):
    gray_lwpCV = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # cv2.imshow('capture', img)
    # cv2.waitKey(0)
    gray_lwpCV = cv2.GaussianBlur(gray_lwpCV, (21, 21), 0)
    if pre_frame is None:
        pre_frame = gray_lwpCV
    else:
        img1 = SMD(pre_frame)
        img2 = SMD(gray_lwpCV)
        diff = img1.astype(np.int) - img2.astype(np.int)
        print('diff', diff)
        # if (120000 < diff < 1400000) | (-100000 < diff < -90000):
        if (500000 < diff < 600000) | (-110000 < diff < -100000):
            print("画面模糊，请求核实")
            fontpath = "font/simsun.ttc"
            font = ImageFont.truetype(fontpath, 32)
            img_pil = Image.fromarray(img)
            draw = ImageDraw.Draw(img_pil)
            draw.text((650, 30), "画面模糊，请求核实", font=font, fill=(0, 0, 255))
            img = np.array(img_pil)
            cv2.imshow('blurry', img)
            cv2.waitKey(0)
            # dst = result + f
            # cv2.imwrite(dst, img)
        # else:
        #     continue
        pre_frame = gray_lwpCV

#***********************遮挡--检测***********************
def occlud(img):
    stdlap=[]
    # 图像切分的尺寸 (3*3)可以自己设置
    cut_size = 2
    # 灰度图
    grey_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 拉普拉斯变换
    gray_lap = cv2.Laplacian(grey_img, cv2.CV_64F)
    grey_img_shape = grey_img.shape
    height, width = grey_img_shape[0], grey_img_shape[1]
    height_div = height // cut_size
    width_div = width // cut_size

    # 循环的尺寸，这样循环就不会取到边界
    range_height_size = height_div * cut_size
    range_width_size = width_div * cut_size
    # 切分循环
    for i in range(0, range_height_size, height_div):
        for j in range(0, range_width_size, width_div):
            # 获取当前区域的灰度图像素
            subimg = grey_img[j: j + width_div, i: i + height_div]
            # 获取当前区域 拉普拉斯算子 的边缘信息像素信息
            sublap = gray_lap[j: j + width_div, i: i + height_div]
            # 获取标准差
            stddev_g = np.std(subimg)
            stddev_l = np.std(sublap)
            print('gray', stddev_g)
            print('LAP', stddev_l)
            stdlap.append(stddev_l)
    #for l in stdlap:
    return round(min(stdlap),3)
    #return stdlap
            # if stddev_g < 40 and stddev_l < 30:
            # if stddev_l < 30:
            #     print("图像遮挡")

#***********************帧图像---main函数***********************
def main_imge(path):
    pre_frame=None
    text = "Video No exception"
    n = 0
    for f in os.listdir(path):
        if (f.endswith(".jpg")):
            imagePath = os.path.join(path, f)
            #demo = Image.open(imagePath)
            image = cv2.imread(imagePath)
            #demo = Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            #image = cv2.resize(image, (int(size[1] * 0.5), int(size[0] * 0.5)), cv2.INTER_LINEAR)
            image = cv2.resize(image, (960,540), cv2.INTER_LINEAR)
            # cv2.putText(image, "{}".format(text), (380,70),
            #             cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.imshow('src',image)
            cv2.waitKey(0 )
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            #gray_lwpCV = cv2.GaussianBlur(gray, (21, 21), 0)

            fm=blur_lap(image,gray)
            #print('blur',fm)
            dark_prop = black(image, gray)
            #print('black',dark_prop)
            stripdata = strip(image)
            #print('strip', stripdata)
            # snowdata = snow_fft(frame1)
            snowdata = snow_check(image)
            #print('snow', snowdata)
            # stripdata=stripe(demo)
            # print(stripdata)
            # snowdata=snow_fft(demo)
            # print(snowdata)
            ocddata=occlud(image)
            #print('occlud',ocddata)

            if fm < args["bludata"]:
                #print('blur')
                fontpath = "font/simsun.ttc"
                font = ImageFont.truetype(fontpath, 20)
                img_pil = Image.fromarray(image)
                draw = ImageDraw.Draw(img_pil)
                draw.text((0, 60), "{}:{:}".format("画面模糊,请求核实", fm), font=font, fill=(0, 0, 255))
                image = np.array(img_pil)
                cv2.imshow("blur", image)
                cv2.waitKey(0)

            elif dark_prop >=args["bladata"]:
                print('black')
                fontpath = "font/simsun.ttc"
                font = ImageFont.truetype(fontpath,20)
                img_pil = Image.fromarray(image)
                draw = ImageDraw.Draw(img_pil)
                draw.text((0, 60), "{}:{:}".format("画面无信号,请求核实",dark_prop), font=font, fill=(0,255,0))
                image = np.array(img_pil)
                cv2.imshow("black", image)
                cv2.waitKey(0)

            elif 0<stripdata<=args["strdata"]:
                print('strip')
                fontpath = "font/simsun.ttc"
                font = ImageFont.truetype(fontpath, 20)
                img_pil = Image.fromarray(image)
                draw = ImageDraw.Draw(img_pil)
                draw.text((0, 60), "{}:{:}".format("画面条纹,请求核实", stripdata), font=font, fill=(255, 0, 0))
                image = np.array(img_pil)
                cv2.imshow("strip", image)
                cv2.waitKey(0)

            elif snowdata >=args["snodata"]:
                print('snow')
                fontpath = "font/simsun.ttc"
                font = ImageFont.truetype(fontpath, 20)
                img_pil = Image.fromarray(image)
                draw = ImageDraw.Draw(img_pil)
                draw.text((0, 60),"{}:{}".format("画面雪花,请求核实", snowdata), font=font, fill=(0, 0, 255))
                image = np.array(img_pil)
                cv2.imshow("snow", image)
                cv2.waitKey(0)

            elif ocddata<args["ocddata"]:
                print('occlud')
                fontpath = "font/simsun.ttc"
                font = ImageFont.truetype(fontpath, 20)
                img_pil = Image.fromarray(image)
                draw = ImageDraw.Draw(img_pil)
                draw.text((0, 60), "{}:{}".format("画面遮挡,请求核实", snowdata), font=font, fill=(0, 0, 255))
                image = np.array(img_pil)
                cv2.imshow("occlud", image)
                cv2.waitKey(0)
            else:
                continue

#***********************实时video---main函数***********************
def mian_video(vc):
    # fps = 10
    while (1):
        #start = time.time()
        # 读取视频流
        ret, frame = vc.read()
        size = frame.shape
        frame = cv2.resize(frame, (int(size[1] * 0.5), int(size[0] * 0.5)), cv2.INTER_LINEAR)
        frame1 = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        if not ret:
            break
        end = time.time()
        cv2.imshow('capture', frame)
        cv2.waitKey(60)

        # seconds = end - start
        # if seconds < 1.0 / fps:
        #     time.sleep(1.0 / fps - seconds)
        fm = blur_lap(frame, gray)
        print('blur',fm)
        dark_prop = black(frame, gray)
        print('black',dark_prop)
        # stripdata = stripe(frame1)
        stripdata=strip(frame)
        print('strip',stripdata)
        # snowdata = snow_fft(frame1)
        snowdata=snow_check(frame)
        print('snow',snowdata)

        if fm < args["bludata"]:
            print('blur')
            fontpath = "font/simsun.ttc"
            font = ImageFont.truetype(fontpath, 32)
            img_pil = Image.fromarray(frame)
            draw = ImageDraw.Draw(img_pil)
            draw.text((500, 50), "{}:{:}".format("画面模糊,请求核实", fm), font=font, fill=(0, 0, 255))
            frame = np.array(img_pil)
            cv2.imshow("blur", frame)
            cv2.waitKey(0)

        elif dark_prop >= args["bladata"]:
            print('black')
            fontpath = "font/simsun.ttc"
            font = ImageFont.truetype(fontpath, 32)
            img_pil = Image.fromarray(frame)
            draw = ImageDraw.Draw(img_pil)
            draw.text((500, 50), "{}:{:}".format("画面无信号,请求核实", dark_prop), font=font, fill=(0, 255, 0))
            frame = np.array(img_pil)
            cv2.imshow("black", frame)
            cv2.waitKey(0)

        elif 0<stripdata<=args["strdata"]:
            print('strip')
            fontpath = "font/simsun.ttc"
            font = ImageFont.truetype(fontpath, 32)
            img_pil = Image.fromarray(frame)
            draw = ImageDraw.Draw(img_pil)
            draw.text((500, 50), "{}:{:}".format("画面条纹,请求核实", stripdata), font=font, fill=(255, 0, 0))
            frame = np.array(img_pil)
            cv2.imshow("strip", frame)
            cv2.waitKey(0)

        elif snowdata >= args["snodata"]:
            print('snow')
            fontpath = "font/simsun.ttc"
            font = ImageFont.truetype(fontpath, 32)
            img_pil = Image.fromarray(frame)
            draw = ImageDraw.Draw(img_pil)
            draw.text((500, 50), "{}:{}".format("画面雪花,请求核实", snowdata), font=font, fill=(0, 0, 255))
            frame = np.array(img_pil)
            cv2.imshow("snow", frame)
            cv2.waitKey(0)
        else:
            continue
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    vc.release()

#***********************循环video-IP---main函数if __name__ == '__main__':***********************
def vc_ip():
    #initdir = "onlinedata/timeimg"
    # if(not os.path.exists(os.path.join(maindir,initdir))):
    # os.makedirs(os.path.join(maindir,initdir))
    text = "Video Exception"
    while (1):
        ipc = get_iplist()
        for ip in ipc:
            try:
                rtsp = "rtsp://{}:{}@{}:554/Streaming/Channels/1".format(ip[2], ip[3], ip[1])
                cap = cv2.VideoCapture(rtsp)
                ret, frame = cap.read()
                print(ip[1])
                if not ret:
                    print(ret)
                    print('Unable to call')
                    continue
                # size = frame.shape
                # frame = cv2.resize(frame, (int(size[1] * 0.5), int(size[0] * 0.5)), cv2.INTER_LINEAR)
                frame=cv2.resize(frame, (960, 540), interpolation=cv2.INTER_CUBIC)
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                cv2.imshow('capture', frame)
                cv2.waitKey(10)

                # seconds = end - start
                # if seconds < 1.0 / fps:
                #     time.sleep(1.0 / fps - seconds)
                fm = blur_lap(frame, gray)
                print('blur', fm)
                dark_prop = black(frame, gray)
                print('black', dark_prop)
                # stripdata = stripe(frame1)
                stripdata = strip(frame)
                print('strip', stripdata)
                # snowdata = snow_fft(frame1)
                snowdata = snow_check(frame)
                print('snow', snowdata)
                ocddata = occlud(frame)
                print('occlud', ocddata)

                if fm < args["bludata"]:
                    print('blur')
                    fontpath = "font/simsun.ttc"
                    font = ImageFont.truetype(fontpath, 32)
                    img_pil = Image.fromarray(frame)
                    draw = ImageDraw.Draw(img_pil)
                    draw.text((400, 60), "{}:{}:{}".format(ip[1],"模糊,请核实", fm), font=font, fill=(0, 0, 255))
                    frame = np.array(img_pil)
                    cv2.imshow("blur", frame)
                    cv2.waitKey(0)

                elif dark_prop >= args["bladata"]:
                    print('black')
                    fontpath = "font/simsun.ttc"
                    font = ImageFont.truetype(fontpath, 32)
                    img_pil = Image.fromarray(frame)
                    draw = ImageDraw.Draw(img_pil)
                    draw.text((400, 60), "{}:{}:{}".format(ip[1],"无信号,请核实", dark_prop), font=font, fill=(0, 255, 0))
                    frame = np.array(img_pil)
                    cv2.imshow("black", frame)
                    cv2.waitKey(0)

                elif 0 < stripdata <= args["strdata"]:
                    print('strip')
                    fontpath = "font/simsun.ttc"
                    font = ImageFont.truetype(fontpath, 32)
                    img_pil = Image.fromarray(frame)
                    draw = ImageDraw.Draw(img_pil)
                    draw.text((400, 60), "{}:{}:{}".format(ip[1],"条纹,请核实", stripdata), font=font, fill=(255, 0, 0))
                    frame = np.array(img_pil)
                    cv2.imshow("strip", frame)
                    cv2.waitKey(0)

                elif snowdata >= args["snodata"]:
                    print('snow')
                    fontpath = "font/simsun.ttc"
                    font = ImageFont.truetype(fontpath, 32)
                    img_pil = Image.fromarray(frame)
                    draw = ImageDraw.Draw(img_pil)
                    draw.text((400, 60), "{}:{}:{}".format(ip[1],"雪花,请核实", snowdata), font=font, fill=(0, 0, 255))
                    frame = np.array(img_pil)
                    cv2.imshow("snow", frame)
                    cv2.waitKey(0)

                elif 20<ocddata < args["ocddata"]:
                    print('occlud')
                    fontpath = "font/simsun.ttc"
                    font = ImageFont.truetype(fontpath, 32)
                    img_pil = Image.fromarray(frame)
                    draw = ImageDraw.Draw(img_pil)
                    draw.text((400, 60), "{}:{}".format("画面遮挡,请求核实", ocddata), font=font, fill=(0, 0, 255))
                    frame = np.array(img_pil)
                    cv2.imshow("occlud", frame)
                    cv2.waitKey(0)
                else:
                    continue

                # dtstr = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
                # savdir = os.path.join(maindir, initdir, ip[1], dtstr[:8])
                # if (not os.path.exists(savdir)):
                #     print('********')
                    # os.makedirs(savdir)
                #newname = ip[1] + "_" + dtstr + ".jpg"
                # cv2.imwrite(os.path.join(savdir, newname), frame)
                #cap.release()
            except Exception as e:
                print("error", ip[0], ip[1])

                im =  np.ones((540, 960, 3), dtype="uint8")
                im[:]=(255,255,255)
                cv2.putText(im, "{}:{}:{}".format(text,ip[0],ip[1]), (380, 70),
                                         cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                cv2.imshow("error", im)
                cv2.waitKey(0)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()

if __name__ == '__main__':
    # vc = cv2.VideoCapture(r"D:\video project\mohu\mohu_20201124083031.mp4")
    # mian_video(vc)
    #path = "D:/video project/vdata/timeimg/10.199.146.131/20201216"
    # path1=r"D:\video project\vdata\temptest"
    # main_imge(path1)
    vc_ip()

