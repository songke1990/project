#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2020/12/15 下午 02:06
#@Author: SGK
#@File  : loopIP.py
import os
import re
import datetime
import cv2
from apscheduler.schedulers.blocking import BlockingScheduler

# print(os.path.abspath(__file__))
# os.remove(__file__)
maindir = "D:/pycharmproject/video/"


def main():
    # get_initimg()
    time_exe()

def time_exe():
    scheduler = BlockingScheduler()
    # scheduler.add_job(job, 'cron', day_of_week='1-5', hour=6, minute=30)
    scheduler.add_job(getimg, 'interval', minutes=0.03)
    scheduler.start()

def getimg():
    initdir = "onlinedata/timeimg"
    # if(not os.path.exists(os.path.join(maindir,initdir))):
    # os.makedirs(os.path.join(maindir,initdir))
    ipc = get_iplist()
    for ip in ipc:
        try:
            rtsp = "rtsp://{}:{}@{}:554/Streaming/Channels/1".format(ip[2], ip[3], ip[1])
            cap = cv2.VideoCapture(rtsp)
            ret, frame = cap.read()
            size = frame.shape
            frame = cv2.resize(frame, (int(size[1] * 0.5), int(size[0] * 0.5)), cv2.INTER_LINEAR)
            cv2.imshow('1'+ip[1],frame)
            cv2.waitKey(0)
            dtstr = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            savdir = os.path.join(maindir, initdir, ip[1], dtstr[:8])
            if (not os.path.exists(savdir)):
                print('********')
                #os.makedirs(savdir)
            newname = ip[1] + "_" + dtstr + ".jpg"
            #cv2.imwrite(os.path.join(savdir, newname), frame)
            cap.release()
        except Exception as e:
            print("error", ip[0], ip[1])

def get_initimg():
    initdir = "onlinedata/initimg"
    if (not os.path.exists(os.path.join(maindir, initdir))):
        os.makedirs(os.path.join(maindir, initdir))
    ipc = get_iplist()
    for ip in ipc:
        try:
            rtsp = "rtsp://{}:{}@{}:554/Streaming/Channels/1".format(ip[2], ip[3], ip[1])
            cap = cv2.VideoCapture(rtsp)
            ret, frame = cap.read()
            savdir = os.path.join(maindir, initdir, ip[1])
            if (not os.path.exists(savdir)):
                os.makedirs(savdir)
            dtstr = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
            newname = ip[1] + "_" + dtstr + ".jpg"
            cv2.imwrite(os.path.join(savdir, newname), frame)
            cap.release()
        except Exception as e:
            print("error", ip[0], ip[1])

def get_iplist():
    ipc = []
    lines = open(os.path.join(maindir, "cammerIP.txt")).readlines()
    for line in lines:
        items = re.split(r"[ ]+", line.strip(" \t\n\r"))
        items[0] = items[0].strip(":")
        #print(items[0])
        ipc.append(items)
        #print(ipc)
    return ipc

if __name__ == '__main__':
    #main()
    ip = get_iplist()
    print(ip)
    getimg()

