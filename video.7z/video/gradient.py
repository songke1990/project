#!/usr/bin/env python
# -*- coding:utf-8 -*-
#@Time  : 2020/11/20 上午 09:30
#@Author: SGK
#@File  : detct.py
import cv2
import numpy as np
import math
#*****************SMD(灰度方差函数)梯度函数**********
def SMD3(img):
    img1= cv2.copyMakeBorder(img,0,0,1,0, cv2.BORDER_CONSTANT,value=[0,0,0])
    img2= cv2.copyMakeBorder(img,0,0,0,1, cv2.BORDER_CONSTANT,value=[0,0,0])
    data0 = np.array((img1[:,:]),dtype=np.int)
    data00 = np.array((img2[:,:]),dtype=np.int)
    d=cv2.subtract(data0,data00)
    d1=cv2.convertScaleAbs(d[1:-1,1:-1])
    d2=d1[:,:].flatten()
    j=d2.sum()

    img3= cv2.copyMakeBorder(img,1,0,0,0, cv2.BORDER_CONSTANT,value=[0,0,0])
    img4= cv2.copyMakeBorder(img,0,1,0,0, cv2.BORDER_CONSTANT,value=[0,0,0])
    data1 = np.array((img3[:,:]),dtype=np.int)
    data2 = np.array((img4[:,:]),dtype=np.int)
    c=cv2.subtract(data1,data2)
    c1=cv2.convertScaleAbs(c[1:-1,1:-1])
    c2=c1[:,:].flatten()
    h=c2.sum()
    out=h+j
    return out

#*****************SMD(灰度方差函数)梯度函数**********
def SMD(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    shape = np.shape(img)
    out = 0
    for x in range(1, shape[0]-1):
        for y in range(0, shape[1]):
            out+=math.fabs(int(img[x,y])-int(img[x,y-1]))
            out+=math.fabs(int(img[x,y]-int(img[x+1,y])))
    return out

#*****************SMD2（灰度方差函数）梯度函数**********
def SMD2(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]-1):
            out+=math.fabs(int(img[x,y])-int(img[x+1,y]))*math.fabs(int(img[x,y]-int(img[x,y+1])))
    return out

#*****************brenner梯度函数**********
def brenner(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-2):
        for y in range(0, shape[1]):
            out+=(int(img[x+2,y])-int(img[x,y]))**2
    return out

#*****************方差梯度函数**********
def variance(img):#函数对噪声比较敏感，图像画面越纯净，函数值越小。
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    out = 0
    u = np.mean(img)
    shape = np.shape(img)
    for x in range(0,shape[0]):
        for y in range(0,shape[1]):
            out+=(img[x,y]-u)**2
    return out

#*****************能量梯度函数**********
def energy(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    shape = np.shape(img)
    out = 0
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]-1):
            out+=((int(img[x+1,y])-int(img[x,y]))**2)*((int(img[x,y+1]-int(img[x,y])))**2)
    return out

#*****************Vollath梯度函数**********整幅图灰度像素
def Vollath(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    shape = np.shape(img)
    u = np.mean(img)
    out = -shape[0]*shape[1]*(u**2)
    for x in range(0, shape[0]-1):
        for y in range(0, shape[1]):
            out+=int(img[x,y])*int(img[x+1,y])
    return out

#*****************entropy（熵）函数**********
def entropy(img):#熵函数灵敏度不高，依据图像内容不同容易出现与真实情况相反的结果。
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    out = 0
    count = np.shape(img)[0]*np.shape(img)[1]
    p = np.bincount(np.array(img).flatten())
    for i in range(0, len(p)):
        if p[i]!=0:
            out-=p[i]*math.log(p[i]/count)/count
    return out

#*****************Laplacian函数**********
def Laplacian(img):
    '''
    :param img:narray 二维灰度图像
    :return: float 图像越清晰越大
    '''
    return cv2.Laplacian(img,cv2.CV_64F).var()

def main(img1, img2):
    print('Brenner',brenner(img1),brenner(img2))
    #print('Laplacian',Laplacian(img1),Laplacian(img2))
    print('SMD',SMD(img1), SMD(img2))
    print('SMD2',SMD2(img1), SMD2(img2))
    print('Variance',variance(img1),variance(img2))
    print('Energy',energy(img1),energy(img2))
    print('Vollath',Vollath(img1),Vollath(img2))
    #print('Entropy',entropy(img1),entropy(img2))

if __name__ == '__main__':
    #读入原始图像
    img1 = cv2.imread('D:/video project/video/data/1.jpg')
    img2 = cv2.imread('D:/video project/video/data/2.jpg')
    #灰度化处理
    img1 = cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)
    cv2.imshow('1.jpg',img1)
    img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    cv2.imshow('2.jpg', img2)
    main(img1,img2)
