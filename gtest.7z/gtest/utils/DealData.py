import sys
sys.path.append('/root/gtest/')
sys.path.append('./')
sys.path.append('../')
import logging
import json
import time
import pymysql
import jieba
import numpy as np
from utils.langconv import *
import time
from options.options import Options
from suds.client import Client
logging.basicConfig(level=logging.INFO)
logging.getLogger('suds.client').setLevel(logging.DEBUG)

class DealWebService(object):
    def __init__(self):
        self.client = None
        opt = Options().parse()
        self.dm = DealMysql(opt)
        self._conn()

    def _conn(self):
        #self.client = Client('http://10.172.112.203:1002/GSProject.asmx?wsdl')
        self.client=Client('http://service.idpbg.efoxconn.com/gsproject/GSProject.asmx?wsdl')

    def _gen_sql(self, result, save_case):#更新数据库
        flag = False
        sql_list = []
        #sql = """INSERT INTO `lian` VALUES """
        sql="""INSERT INTO `lian`(FORM_CODE,FORM_ID,FORM_STATUS,DEL_FLAG,CREATE_TIME,LAST_EDIT_DATE,IMPROVE_DESC,PLAN_SOLUTION) VALUES """
        for item in json.loads(result):
            if item['FORM_CODE'] not in save_case:
                continue
            '''
            values = """('{}', '{}', {}, {}, '{}', '{}', '{}', '{}', {}, '{}', '{}', '{}', '{}', '{}', {}, '{}', '{}', '{}', {}, '{}',
             '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', '{}', {}, '{}', {}, '{}', '{}', '{}', '{}', '{}', '{}', '{}', 
             '{}', '{}', {}, '{}', '{}', '{}', '{}', '{}', '{}', {}, '{}', '{}', '{}', '{}', '{}')""".format(
                item['FORM_CODE'], item['FORM_ID'], item['FORM_STATUS'], item['DEL_FLAG'], item['CREATE_TIME'],
                item['CREATE_USER'], item['LAST_EDIT_DATE'], item['LAST_EDIT_USER'], item['IS_INVALID'],
                item['FORM_PRE_ID'], item['PROCESS_ID'], item['EMP_NO'], item['EMP_NAME'], item['FACTORY_ID'],
                item['DEPT_ID'], item['DEPT_NAME'], item['POST_LEVEL'], item['HEAD_SHIP'],
                item['DEPT_CHU_ID'], item['DEPT_CHU_NAME'], item['EMP_MOBILE_TEL'], item['DEPT_COST'], item['MAIL'],
                item['EXT_NO'], item['APPLY_FAC_ID'], item['APPLY_BU_ID'],
                item['APPLY_DATE'], item['ESTIMATED_DATE'], item['APPLY_CASE_ID'], item['APPLY_CASE_NAME'],
                item['APPLY_DEPT_CHU_ID'], item['APPLY_DEPT_CHU_NAME'],
                item['ONCE_COST'], item['PRE_FAMILY_ID'], item['PRE_PROCESS_ID'], item['PRE_STATION'],
                item['PROJECT_FILE'], pymysql.escape_string(item['IMPROVE_DESC'].replace('"', '')), pymysql.escape_string(item['PLAN_SOLUTION'].replace('"', '')), item['COMPUTING_METHOD'],
                item['KPCS_DESC'], item['KRMB_DESC'], item['IS_GROUP'], item['PROPERTY_01'], item['PROPERTY_02'],
                item['IT_PRO_APPLY_CODE'], item['PROPERTY_04'], item['PROPERTY_05'], item['IMPROVED_METHOD'],
                item['DEPT_TEAM'], item['KPCS_DESC_CHANGED'], item['KRMB_DESC_CHANGED'], item['REQUEST_NO'],
                item['FORM_ORIGINAL_CODE'], item['FORM_ORIGINAL_TYPE'])
            '''
            values = """('{}', '{}', {}, {}, '{}', '{}', '{}', '{}')""".format(
                item['FORM_CODE'], item['FORM_ID'], item['FORM_STATUS'],
                item['DEL_FLAG'],item['CREATE_TIME'],item['LAST_EDIT_DATE'],
                pymysql.escape_string(item['IMPROVE_DESC'].replace('"', '')),
                pymysql.escape_string(item['PLAN_SOLUTION'].replace('"', '')))
            sql_list.append(sql+values)
            flag = True
        # print(sql)
        return flag, sql_list
        
    def sim_id(self,result):#更新本地数据库-状态-数据
        print('start update')
        #result = self.client.service.GetGSProjectRecordData3(startime, endtime, -1)
        case_sql = "SELECT FORM_CODE, FORM_STATUS, LAST_EDIT_DATE FROM lian"
        sql_res = self.dm.get_info(case_sql)
        for item_D in json.loads(result):
            a=(item_D['FORM_CODE'],item_D['FORM_STATUS'],item_D['LAST_EDIT_DATE'])
            #print(a[0])
            for item_tuple in sql_res:
                fid = item_tuple[0]
                if a[0]==fid:
                    up_sql = 'UPDATE lian SET FORM_STATUS="{}",LAST_EDIT_DATE="{}" WHERE FORM_CODE="{}"'.format(a[1],a[2],a[0])
                    flag=self.dm.update_info(up_sql)
        print('update succeed')
        return flag

    def _gen_case_list(self, result):
        case_list = []
        case_dict = {}
        for item in json.loads(result):
            case_list.append(item['FORM_CODE'])
            case_dict[item['FORM_CODE']] = {'improve': item['IMPROVE_DESC'], 'plan': item['PLAN_SOLUTION']}
        return case_list, case_dict

    def get_status12(self):
        case_sql = "SELECT FORM_CODE, IMPROVE_DESC,PLAN_SOLUTION FROM lian WHERE FORM_STATUS IN (1,2)"
        sql_res = self.dm.get_info(case_sql)
        form_list = []
        save_dict={}
        for item in sql_res:
            form_list.append(item[0])
            save_dict[item[0]] = {'improve': item[1], 'plan': item[2]}
        return  save_dict

    def save_data(self, startime="",endtime=""):
        result = self.client.service.GetGSProjectRecordData3(startime,endtime,-1)
        #result = self.client.service.GetGSProjectFinishedData(date_time)
        if '未查詢到數據' == result:
            return False, None
        case_list, case_dict = self._gen_case_list(result)
        case_sql = "SELECT FORM_CODE FROM lian"
        sql_res = self.dm.get_info(case_sql)
        form_list = []
        for item in sql_res:
            form_list.append(item[0])
        save_case = []
        
        flag,save_dict=False,{}
        if len(list(set(form_list).intersection(set(case_list)))) != 0:
            upflag=self.sim_id(result)#更新本地数据库-状态-数据
            if upflag:
                flag=True
        if len(list(set(form_list).intersection(set(case_list)))) == 0:
            save_case = case_list
        elif len(list(set(case_list).difference(set(form_list)))) > 0:
            save_case = list(set(case_list).difference(set(form_list)))
        gen_flag, sql_list = self._gen_sql(result, save_case)
    
        for sql in sql_list:
            if gen_flag:
                self.dm.add_info(sql)#添加本地数据库数据
               # for case_no in save_case:
                   # save_dict[case_no] = case_dict[case_no]
        return flag, save_dict

class DealCsv(object):
    def __init__(self):
        self.stop_word = []
        self._load_stop()

    def _load_stop(self, path=r'/root/gtest/utils/stop_word.txt'):
        with open(path, 'r', encoding='utf-8') as fr:
            for line in fr:
                self.stop_word.append(line.strip('\n'))

    def cut_doc(self, doc):
        doc = Converter('zh-hans').convert(doc)

        res = []
        for item in jieba.lcut(doc):
            if item not in self.stop_word:
                res.append(item)
        return res

    def gen_model_data(self, new_case=None):#获取mysql数据
        #sql = "SELECT FORM_CODE, IMPROVE_DESC, PLAN_SOLUTION FROM lian WHERE FORM_STATUS=2" #AND CREATE_TIME > '{}'
        sql = "SELECT FORM_CODE, IMPROVE_DESC,PLAN_SOLUTION FROM lian WHERE FORM_STATUS IN (1,2)"
       # sql ="SELECT FORM_CODE, IMPROVE_DESC,PLAN_SOLUTION FROM lian WHERE LAST_EDIT_DATE BETWEEN DATE_SUB(NOW(),INTERVAL 36 MONTH) AND NOW() AND FORM_STATUS IN (1,2);"
        opt = Options().parse()
        dm = DealMysql(opt)
        sql_res = dm.get_info(sql)
        #print(len(sql_res))
        form_code = []
        improve_info = []
        plan_info = []
        data_dict = {}
        for item in sql_res:
            FORM_CODE, IMPROVE_DESC, PLAN_SOLUTION = item
            #print(IMPROVE_DESC)
            form_code.append(FORM_CODE)
            improve_info.append(self.cut_doc(IMPROVE_DESC))
            plan_info.append(self.cut_doc(PLAN_SOLUTION))
            data_dict[FORM_CODE] = {'improve': IMPROVE_DESC, 'plan': PLAN_SOLUTION}
            #print('&&&&&&&&&&&')
            #print(improve_info)
        self.save_case(form_code)

        m_list = np.array(data_dict)
        np.save('label.npy', m_list)
        #print(improve_info)
        return form_code, improve_info, plan_info

    def save_info(self, info, file_name):
        with open(file_name, 'w', encoding='utf-8') as fw:
            for doc in info:
                if file_name.find('case') != -1:
                    fw.write(doc + '\n')
                else:
                    fw.write('\t'.join(doc) + '\n')

    def save_case(self, form_code):
        with open('case.info', 'w', encoding='utf-8') as fw:
            fw.write(','.join([str(item) for item in form_code]))

    def load_case(self):
        with open('case.info', 'r', encoding='utf-8') as fr:
            return fr.read().split(',')

    def load_info(self, file_name):
        res = []
        with open(file_name, 'r', encoding='utf-8') as fr:
            for line in fr:
                res.append(line.strip('\n').split('\t'))
        return res

class DealMysql(object):
    def __init__(self, opt):
        self.opt = opt
        self.cursor = None
        self.conn = None
        self._init_conn()

    def _init_conn(self):
        try:
            self.conn = pymysql.connect(host=self.opt.host,
                                                     user=self.opt.user,
                                                     passwd=self.opt.passwd,
                                                     port=self.opt.port,
                                                     db=self.opt.db,
                                                     charset=self.opt.charset)
            self.cursor = self.conn.cursor()
            return True
        except Exception as ex:
            print(ex)
            return False

    def _reload_conn(self, max_time=28800, stime=3):
        _status, _nums = True, 0
        while _status and _nums < max_time:
            try:
                self.conn.ping()
                _status = False
            except Exception as ex:
                if self._init_conn():
                    _status = False
                    break
                _nums += 1
                time.sleep(stime)

    def close(self):
        if self.cursor:
            self.cursor.close()
        self.conn.commit()
        self.conn.close()

    def _generate_dict(self, record, columns):
        res = {}
        for idx, column in enumerate(columns[1:]):
            res[column] = record[idx + 1]
        return res

    def get_data(self, sql):
        self.cursor.execute(sql)
        res = self.cursor.fetchall()
        return res

    def get_data_by_columns(self, sql, columns):
        res = {}
        self.cursor.execute(sql)
        records = self.cursor.fetchall()
        for record in records:
            if len(columns) > 1:
                tmp_dict = self._generate_dict(record, columns)
                res[record[0]] = tmp_dict
            else:
                res[record[0]] = columns[0]
        return res

    def delete_info(self, sql):
        try:
            self.cursor.execute(sql)
            self.conn.commit()
            return True
        except Exception as ex:
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return False

    def add_info(self, sql):
        res = False
        try:
            self._reload_conn()
            self.cursor.execute(sql)
            self.conn.commit()
            res = True
            return res
        except Exception as ex:
            print(ex)
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return res

    def del_info(self, sql):
        res = -1
        try:
            self._reload_conn()
            res = self.cursor.execute(sql)
            self.conn.commit()
            return res
        except Exception as ex:
            print(ex)
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return res

    def get_info(self, sql):
        try:
            self._reload_conn()
            self.cursor.execute(sql)
            self.conn.commit()
            res = self.cursor.fetchall()
            return res
        except Exception as ex:
            print(ex)
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return res

    def get_info_id(self, sql):
        res = -1
        try:
            self._reload_conn()
            self.cursor.execute(sql)
            self.conn.commit()
            res = self.cursor.fetchall() 
            return res
        except Exception as ex:
            print(ex)
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return res

    def update_info(self, sql):
        res = False
        try:
            self._reload_conn()
            res = self.cursor.execute(sql)
            self.conn.commit()
            res=True
            return res
        except Exception as ex:
            print(ex)
            self.conn.rollback()
            logging.error(' failed info:{}'.format(ex.args))
            return res


if __name__ == '__main__':
    dw = DealWebService()
    dc=DealCsv()
    # dw.get_status12()
    a,b=dw.save_data("2020-11-01", "2020-11-03")
    print(a)
   # print(dc.gen_model_data())

