from utils.DealData import DealCsv
from utils.langconv import *
from gensim import corpora, models, similarities
from collections import defaultdict
import numpy as np
import datetime
import jieba
import os

class GenerateModel(object):
    def __init__(self, path, new_dict=None):
        self.path = path
        self.new_dict = new_dict
        self.stop_word = []
        self._load_stop()
        self.case_list = []
        self.gen_model()

    def _load_stop(self, path=r'utils/stop_word.txt'):#加载停用词
        with open(path, 'r', encoding='utf-8') as fr:
            for line in fr:
                self.stop_word.append(line.strip('\n'))

    def _calc_frequent(self, doc_list):#去掉重复
        frequency = defaultdict(int)
        for doc in doc_list:
            for token in doc[: -1]:
                frequency[token] += 1
        #texts = [[token for token in doc if frequency[token] > 1 and frequency[token] < 1000] for doc in doc_list]
        texts = [[token for token in doc if frequency[token] > 1] for doc in doc_list]
        return texts

    def _gen_bag_word(self, model, texts):#制作词袋
        dictionary = corpora.Dictionary(texts)
        dictionary.save('{}/golden.dic'.format(model))
        self.dictionary = dictionary

    def _gen_corpus_tfidf(self, model, texts):#生成tfidf
        self.corpus = [self.dictionary.doc2bow(doc) for doc in texts]
        corpora.MmCorpus.serialize('{}/corpus.mm'.format(model), self.corpus)
        self.tfidf = models.TfidfModel(self.corpus)

        self.corpus_tfidf = self.tfidf[self.corpus]
        self.index = similarities.SparseMatrixSimilarity(self.tfidf[self.corpus],
                                                         num_features=len(self.dictionary.keys()))
        self.index.save('{}/similarity.sim'.format(model))
        self.tfidf.save('{}/model.tfidf'.format(model))

        self.lsi = models.LsiModel(self.corpus_tfidf)
        self.corpus_lsi = self.lsi[self.corpus_tfidf]
        self.similarity_lsi = similarities.SparseMatrixSimilarity(self.corpus_lsi,
                                                                  num_features=len(self.dictionary.keys()), num_best=20000)
        self.similarity_lsi.save('{}/similarity_lsi.sim'.format(model))
        self.lsi.save('{}/model.lsi'.format(model))
        corpora.MmCorpus.serialize('{}/lsi_corpus.mm'.format(model), self.corpus_lsi)

    def cut_doc(self, doc):#分词
        doc = Converter('zh-hans').convert(doc)
        res = []
        for item in jieba.cut(doc):
            if item not in self.stop_word:
                res.append(item)
        return res

    def _gen_data(self):#生成训练数据
        m_list = np.load('label.npy', allow_pickle=True)
        data_dict = m_list.tolist()
        for case_no in self.new_dict.keys():
            if case_no not in data_dict.keys():
                data_dict[case_no] = self.new_dict[case_no]
        form_code = []
        improve_info = []
        plan_info = []
        for case_no in data_dict.keys():
            FORM_CODE, IMPROVE_DESC, PLAN_SOLUTION = case_no, data_dict[case_no]['improve'], data_dict[case_no]['plan']
            form_code.append(FORM_CODE)
            improve_info.append(self.cut_doc(IMPROVE_DESC))
            plan_info.append(self.cut_doc(PLAN_SOLUTION))
        m_list = np.array(data_dict)
        np.save('label.npy', m_list)
        return form_code, improve_info, plan_info

    def gen_model(self):#生成模型
        dc = DealCsv()
        if None == self.new_dict:
            self.case_list, improve_list, plan_list = dc.gen_model_data()
        else:
            self.case_list, improve_list, plan_list = self._gen_data()
        improve = self._calc_frequent(improve_list)
        imprvoe_path = os.path.join(self.path, 'improve_model')
        self._gen_bag_word(imprvoe_path, improve)
        self._gen_corpus_tfidf(imprvoe_path, improve)

        plan = self._calc_frequent(plan_list)
        plan_path = os.path.join(self.path, 'plan_model')
        self._gen_bag_word(plan_path, plan)
        self._gen_corpus_tfidf(plan_path, plan)


    def test_model(self):#测试模型
        m_list = np.load('label.npy', allow_pickle=True)
        data_dict = m_list.tolist()
        improve_dictionary = corpora.Dictionary.load('improve_model/golden.dic')
        improve_model_lsi = models.LsiModel.load('improve_model/model.lsi')
        improve_sim_lsi = similarities.SparseMatrixSimilarity.load('improve_model/similarity_lsi.sim')
        improve_model_tfidf = models.TfidfModel.load('improve_model/model.tfidf')
        improve_sim1 = similarities.SparseMatrixSimilarity.load('improve_model/similarity.sim')

        plan_dictionary = corpora.Dictionary.load('plan_model/golden.dic')
        plan_model_lsi = models.LsiModel.load('plan_model/model.lsi')
        plan_sim_lsi = similarities.SparseMatrixSimilarity.load('plan_model/similarity_lsi.sim')
        plan_model_tfidf = models.TfidfModel.load('plan_model/model.tfidf')
        plan_sim1 = similarities.SparseMatrixSimilarity.load('plan_model/similarity.sim')
        dc = DealCsv()
        bg_time = datetime.datetime.now()
        test_aim = """1.ET_RF物料異常14K, 客戶要求重工更換元件 2.人工作業，OP問題不易控制，手工維修良率63.24%，良率Goal:91.88%, 良率不達標。報廢率1.47%，報廢Goal:1.2%,報廢率不達標。 3.手工維修培訓週期長，需要兩周時間 4.如何高效高品質維修，RE需要Study更好的方法"""
        # dc = DealCsv()
        test = dc.cut_doc(test_aim)

        test = improve_dictionary.doc2bow(test)
        improve_res = improve_sim_lsi[improve_model_lsi[test]]

        # sim = improve_sim1[improve_model_tfidf[test]]
        # res = sorted(enumerate(sim), key=lambda item: -item[1])
        # improve_res = res[0:100]

        ed_time = datetime.datetime.now()
        print(ed_time - bg_time)
        test_aim = """1、導入自動化維修，由自動化替代人工作業，減少OP問題，提升良率，控制報廢率。 使用自動化維修良率達94.08%，報廢率0.69% 2、縮短培訓週期，培養一個自動化作業員只需1天 3、 標準化 4、其他維修區同步導入"""
        # dc = DealCsv()
        test = dc.cut_doc(test_aim)

        test = plan_dictionary.doc2bow(test)
        plan_res = plan_sim_lsi[plan_model_lsi[test]]

        # sim = plan_sim1[plan_model_tfidf[test]]
        # res = sorted(enumerate(sim), key=lambda item: -item[1])
        # plan_res = res[0:100]

        # print(datetime.datetime.now() - ed_time)
        # a = [item[0] for item in improve_res]
        # b = [item[0] for item in plan_res]
        #
        # print(list(set(a).intersection(set(b))))
        with open('case.info', 'r', encoding='utf-8') as fr:
            case_list = fr.read().split(',')
        # for idx in list(set(a).intersection(set(b))):
        #     print(case_list[idx])

        improve_list = [item[0] for item in improve_res]
        plan_list = [item[0] for item in plan_res]
        improve_dict = {item[0]: item[1] for item in improve_res}
        plan_dict = {item[0]: item[1] for item in plan_res}
        interaction = list(set(improve_list).intersection(set(plan_list)))

        mix_res = {}
        for idx in interaction:
            if idx in improve_dict.keys() and idx in plan_dict.keys():
                print( 0.5 * (improve_dict[idx] + plan_dict[idx]))
                mix_res[case_list[idx]] = round(0.5 * (improve_dict[idx] + plan_dict[idx]), 2)
        sort_res = sorted(mix_res.items(),  key=lambda item: item[1], reverse=True)
        res = []
        for item in sort_res:
            res.append({'simility': item[1], 'case_no': item[0], 'improve': data_dict[item[0]]['improve'], 'plan': data_dict[item[0]]['plan']})
        print(res)

if __name__ == '__main__':
    gm = GenerateModel('modelA')
   # print(datetime.datetime.now())
    gm.gen_model()
   # print(datetime.datetime.now())
    #gm.test_model()
   # print(datetime.datetime.now())

