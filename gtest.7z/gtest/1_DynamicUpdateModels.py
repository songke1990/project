import os
import time
import fcntl
from GenerateModel import GenerateModel
import logging
from options.options import Options
from utils.DealData import DealWebService, DealMysql
from datetime import datetime, timedelta

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s [%(filename)s] %(levelname)s:%(message)s',
                    filename='../log/run_time.log',
                    filemode='a')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class DynamicUpdateModel(object):
    def __init__(self):
        self.opt = Options().parse()
        self._check_file_path()
        self.case_list = []
        pass

    def _check_file_path(self):
        if not os.path.exists(self.opt.flag_path):
            os.mknod(self.opt.flag_path)
        if not os.path.exists(self.opt.log_path):
            os.mknod(self.opt.log_path)

    def update_model(self, new_dict):
        with open(self.opt.flag_path, 'r+', encoding='utf-8') as fp:
            fcntl.flock(fp, fcntl.LOCK_EX)
            line = fp.read()
            model_name = ''
            starttime = time.time()
            if line == '':
                model_name = 'modelA'
            else:
                if 'modelA' in line:
                    model_name = 'modelB'
                if 'modelB' in line:
                    model_name = 'modelA'
            gm = GenerateModel(model_name, new_dict)
            self.case_list = gm.case_list
            consume_time = time.time() - starttime
            fp.seek(0)
            fp.truncate()
            fp.write(model_name)
            logger.info(
                'Class Name:{} current model name:{} model update consume time:{}s'.format(self.__str__(), model_name,
                                                                                           consume_time))
            fp.flush()
            fcntl.flock(fp, fcntl.LOCK_UN)



    def monitor_status_and_update(self, min=0):#自动跟新模型
        flag = False
        while True:
            dws = DealWebService()
            logger.info('Class  Name:{}  cur time:{}'.format(self.__str__(), datetime.now()))
            cur_time = datetime.now().strftime('%Y-%m-%d')
            yesterday = (datetime.now() -timedelta(days=1)).strftime('%Y-%m-%d')
            if 1== datetime.now().hour and flag == False: #run one time of every day at 1
                flag, save_dict = dws.save_data(yesterday,cur_time)#每天更新数据 
                if flag==True: 
                    self.update_model(None)
            flag = False
            time.sleep(min * 60)

    def up(self):#手动更新模型
        dws = DealWebService()
        cur_time = datetime.now().strftime('%Y-%m-%d')
        yesterday = (datetime.now() -timedelta(days=1)).strftime('%Y-%m-%d')
       # flag, save_dict = dws.save_data(yesterday,cur_time)#每天更新数据库
        print('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&')
       # status12_data=dws.get_status12()
       # print(len(status12_data))
        self.update_model(None)
              



if __name__ == '__main__':
    dum = DynamicUpdateModel()
   # dum.up()
    dum.monitor_status_and_update(60)
