import argparse

class Options(object):
    def __init__(self):
        self.opt = None
        self.parser = argparse.ArgumentParser()

        # self.parser.add_argument('--data_source', type=str, default=r'off_line', help=r'data source flag')
        self.parser.add_argument('--model_path', type=list, default=['modelA', '../modelB', 'model_backup', '../model'], help=r'model document path')
        self.parser.add_argument('--log_path', type=str, default='../log/run_time.log', help=r'model document path')
        self.parser.add_argument('--flag_path', type=str, default='../log/flag.txt', help=r'model document path')
        self.parser.add_argument('--subject_term', type=str, default=r'utils/dict.txt', help=r'subject term file path')
        self.parser.add_argument('--simility_term', type=str, default=r'utils/simility.txt', help=r'simility term file path')
        self.parser.add_argument('--stop_words', type=str, default=r'utils/stop_word.txt', help=r'stop term file path')

        self.parser.add_argument('--dictionary', type=str, default=r'/golden.dic', help=r'dictionary file path')
        self.parser.add_argument('--corpus', type=str, default='/corpus.mm', help=r'dictionary file path')
        self.parser.add_argument('--tfidf', type=str, default='/model.tfidf', help=r'dictionary file path')
        self.parser.add_argument('--similarity', type=str, default='/similarity.sim', help=r'dictionary file path')
        self.parser.add_argument('--lsi', type=str, default='/model.lsi', help=r'dictionary file path')
        self.parser.add_argument('--similarity_lsi', type=str, default='/similarity_lsi.sim', help=r'dictionary file path')
        self.parser.add_argument('--lsi_corpus', type=str, default='/lsi_corpus.mm', help=r'dictionary file path')
        self.parser.add_argument('--inverts', type=str, default=r'/inverts.mm', help=r'inverts file path')
        self.parser.add_argument('--invertsdocuments', type=str, default=r'/invertsdocuments.mm', help=r'inverts file path')
        self.parser.add_argument('--invert', type=str, default='/invert.mm', help=r'invert file path')

        self.parser.add_argument('--documents', type=str, default='E:\data_source\content', #r'E:\DOWNLOAD\answer_question\txtFile',
                                 help=r'documents file path')
        self.parser.add_argument('--source_documents', type=str, default=r"E:\data_source\current_document", #r'E:\DOWNLOAD\answer_question\source'
                                 help=r'source_documents file path')
        self.parser.add_argument('--abstracts', type=str, default=r'E:\DOWNLOAD\answer_question\abstactFile',
                                 help=r'abstracts file path')
        self.parser.add_argument('--file_list', type=str, default=r'D:\PROJECT_2019\DocumentSearch\utils\file_list.txt',
                                 help=r'abstracts file path')


        self.parser.add_argument('--data_source', type=str, default='mysql', help=r'data source type') #xiaozhi, xiaoai
        self.parser.add_argument('--thread_nums', type=int, default=1, help=r'deal documents thread nums')

        self.parser.add_argument('--host', type=str, default='10.195.227.131', help=r'mysql host ip')
        self.parser.add_argument('--user', type=str, default='root', help=r'database username') #'bigdata_xiaoaiapi' isd_sfcrobot
        self.parser.add_argument('--passwd', type=str, default='xiao2019', help=r'database user password') #'xiaoaiapi_bigdata' sfcrobot_isd
        self.parser.add_argument('--port', type=int, default=3306, help=r'database service port')
        self.parser.add_argument('--db', type=str, default='test', help=r'database instance name') #'ics_r1' sfc_robot
        self.parser.add_argument('--charset', type=str, default='utf8mb4', help=r'database charset')

        self.parser.add_argument('--service_port', type=int, default=5129, help=r'default service port')
        self.parser.add_argument('--test_port', type=int, default=5128, help=r'test port')


    def parse(self):
        self.opt = self.parser.parse_args()
        return self.opt
