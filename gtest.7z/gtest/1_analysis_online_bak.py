from flask import Flask, jsonify
from flask_cors import CORS
from flask_restful import reqparse, Api, Resource
from tornado import wsgi
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from options.options import Options
import logging
import fcntl
import time
import threading
import traceback
from gd_compare import gd_compare
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s [%(filename)s] %(levelname)s:%(message)s',
                    filename='../log/REST.log',
                    filemode='a')
logging.getLogger("requests").setLevel(logging.INFO)

app = Flask(__name__)
api = Api(app)
app.logger.setLevel(logging.INFO)
CORS(app, resources=r'/*')
muxlock = threading.Lock()
cmp_list = [gd_compare('.'), gd_compare('.')]
model_flag = 0
#cmp_test = gd_compare('.')

def reload_model_by_flag():#重载模型
    global cmp_list, model_flag, logging
    current_model = 'modelC'
    while True:
        with open(opt.flag_path, 'r') as fr:
            try:
                fcntl.flock(fr, fcntl.LOCK_EX)
                model_name = fr.read().strip('\n')
                fcntl.flock(fr, fcntl.LOCK_UN)
            except Exception as e:
                logging.error(e)
                continue
            if current_model != model_name:
                tmp_flag = -1
                if 'modelA' == model_name:
                    tmp_flag = 0
                elif 'modelB' == model_name:
                    tmp_flag = 1
                else:
                   continue
                current_model = model_name
                cmp_list[tmp_flag] = gd_compare(model_name)
                muxlock.acquire()
                model_flag = tmp_flag
                muxlock.release()
                logging.info('load {} succeed!'.format(model_name))
            time.sleep(600) 

def gen_res(data):
    res = {"status":  0 if None == data else 1, "data": data, "totals": 0 if None == data else len(data)}
    return res


class DealCompare(Resource):#测试接口
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('improve')
        self.parser.add_argument('plan')

    def post(self):
        try:
            data = None
            args = self.parser.parse_args()
            improve = args.get('improve')
            plan = args.get('plan')
            args = {'improve': improve, 'plan': plan}
            data = cmp_list[model_flag].compare(args)
            res = gen_res(data)
            return jsonify(res)
        except Exception as ex:
           # print('ddccDealShowConfig error ', ex)
            logging.error('Dealcompare error {}'.format(ex))
        return jsonify('')

class TestCompare_isd(Resource):#前端接口
    def __init__(self):
        self.parser = reqparse.RequestParser()
        self.parser.add_argument('improve')
        self.parser.add_argument('plan')

    def post(self):
        try:
            data = None
            args = self.parser.parse_args()
            improve = args.get('improve')
            plan = args.get('plan')
            args = {'improve': improve, 'plan': plan}
            data = cmp_list[model_flag].compare(args)
            res = gen_res(data["b"])
            return jsonify(res)
        except Exception as ex:
            print('TestCompare_isd error ', ex)
            logging.error(traceback.format_exc())
            #logging.error('testcompre_isd error {}'.format(ex))
        return jsonify('')

# api.add_resource(DealCompare, '/test')

api.add_resource(TestCompare_isd, '/compare')

if __name__ == '__main__':
    opt = Options().parse()
    service_ports = opt.service_port
    t = threading.Thread(target=reload_model_by_flag, args=())
    t.start()
    http_server = HTTPServer(wsgi.WSGIContainer(app))
    try:
        http_server.listen(service_ports)
        logging.warning('{} start succeed'.format(service_ports))
        IOLoop.instance().start()
    except Exception as e:
        logging.error('class name:{}, port:{}, Service start failed info:{}'.format('SearchServiceOnline', service_ports, e))
