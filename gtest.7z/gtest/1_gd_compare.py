from utils.DealData import DealCsv
from gensim import corpora, models, similarities
from collections import defaultdict
import datetime
import numpy as np

class gd_compare(object):
    def __init__(self, model_name):
        self.improve_dictionary = corpora.Dictionary.load('{}/improve_model/golden.dic'.format(model_name))
        self.improve_model_lsi = models.LsiModel.load('{}/improve_model/model.lsi'.format(model_name))
        self.improve_sim_lsi = similarities.SparseMatrixSimilarity.load('{}/improve_model/similarity_lsi.sim'.format(model_name))
        self.improve_model_tfidf = models.TfidfModel.load('{}/improve_model/model.tfidf'.format(model_name))
        #self.improve_sim1 = similarities.SparseMatrixSimilarity.load('{}/improve_model/similarity.sim'.format(model_name))

        self.plan_dictionary = corpora.Dictionary.load('{}/plan_model/golden.dic'.format(model_name))
        self.plan_model_lsi = models.LsiModel.load('{}/plan_model/model.lsi'.format(model_name))
        self.plan_sim_lsi = similarities.SparseMatrixSimilarity.load('{}/plan_model/similarity_lsi.sim'.format(model_name))
        self.plan_model_tfidf = models.TfidfModel.load('{}/plan_model/model.tfidf'.format(model_name))
        #self.plan_sim1 = similarities.SparseMatrixSimilarity.load('{}/plan_model/similarity.sim'.format(model_name))

        m_list = np.load('label.npy', allow_pickle=True)
        self.data_dict = m_list.tolist()
        self.dc = DealCsv()
#********************* 对比测试 *******************
    def compare_test(self, data):
        self.case_list = self.dc.load_case()
        improve = self.dc.cut_doc(data['improve'])
        improve = self.improve_dictionary.doc2bow(improve)
        improve_res = self.improve_sim_lsi[self.improve_model_lsi[improve]]
        # sim = self.improve_sim1[self.improve_model_tfidf[improve]]
        # res = sorted(enumerate(sim), key=lambda item: -item[1])
        # improve_res = res[0:500]

        plan = self.dc.cut_doc(data['plan'])
        plan = self.plan_dictionary.doc2bow(plan)
        plan_res = self.plan_sim_lsi[self.plan_model_lsi[plan]]
        # sim = self.plan_sim1[self.plan_model_tfidf[plan]]
        # res = sorted(enumerate(sim), key=lambda item: -item[1])
        # plan_res = res[0:500]

        improve_list = [item[0] for item in improve_res]
        plan_list = [item[0] for item in plan_res]
        improve_dict = {item[0]: item[1] for item in improve_res}
        plan_dict = {item[0]: item[1] for item in plan_res}
        interaction = list(set(improve_list).intersection(set(plan_list)))

        mix_res = {}
        for idx in interaction:
            if idx in improve_dict.keys() and idx in plan_dict.keys():
                mix_res[self.case_list[idx]] = round(0.5 * (improve_dict[idx] + plan_dict[idx]), 2)

        sort_res = sorted(mix_res.items(), key=lambda item: item[1], reverse=True)

        res = []
        for item in sort_res:
            res.append({'simility': item[1], 'case_no': item[0], 'improve': self.data_dict[item[0]]['improve'], 'plan': self.data_dict[item[0]]['plan']})

        return res[:5]

    def compare(self, data):#相似度计算
        self.case_list = self.dc.load_case()
        improve = self.dc.cut_doc(data['improve'])
        improve = self.improve_dictionary.doc2bow(improve)
        improve_res = self.improve_sim_lsi[self.improve_model_lsi[improve]]

        plan = self.dc.cut_doc(data['plan'])
        plan = self.plan_dictionary.doc2bow(plan)
        plan_res = self.plan_sim_lsi[self.plan_model_lsi[plan]]

        bg_time = datetime.datetime.now()
        improve_list = [item[0] for item in improve_res[0: 500]]
        plan_list = [item[0] for item in plan_res[0: 500]]
        improve_dict = {item[0]: item[1] for item in improve_res}
        plan_dict = {item[0]: item[1] for item in plan_res}

        interaction = list(set(list(set(improve_list).intersection(set(plan_list))) + plan_list[: 10] + improve_list[: 10]))
        mix_res = {}
        for idx in interaction:
            #print(improve_dict[idx])
            if idx in improve_dict.keys() and idx in plan_dict.keys():
                mix_res[self.case_list[idx]] = round(0.48 * (improve_dict[idx] + plan_dict[idx]), 2)
            elif idx in improve_dict.keys():
                mix_res[self.case_list[idx]] = round((improve_dict[idx]), 2)
            elif idx in plan_dict.keys():
                mix_res[self.case_list[idx]] = round((plan_dict[idx]), 2)

        sort_res = sorted(mix_res.items(), key=lambda item: item[1], reverse=True)
        res_a = []
        for item in sort_res:
            res_a.append({'simility': item[1], 'case_no': item[0], 'improve': self.data_dict[item[0]]['improve'], 'plan': self.data_dict[item[0]]['plan']})

        a_time = datetime.datetime.now() - bg_time
        bg_time = datetime.datetime.now()
        mix_res_b = {}
        for idx in improve_dict.keys():
            if idx in plan_dict.keys():
                mix_res_b[self.case_list[idx]] = round(0.48 * (improve_dict[idx] + plan_dict[idx]), 2)
        sort_res = sorted(mix_res_b.items(), key=lambda item: item[1], reverse=True)
        res_b = []
        for item in sort_res:
            res_b.append({'simility': item[1], 'case_no': item[0], 'improve': self.data_dict[item[0]]['improve'],
                          'plan': self.data_dict[item[0]]['plan']})
        b_time = datetime.datetime.now() - bg_time
        return {"a": res_a[:6], "b": res_b[: 6], "a_time": str(a_time), "b_time": str(b_time)}

    def _calc_frequent(self, doc_list):
        frequency = defaultdict(int)
        for doc in doc_list:
            for token in doc[: -1]:
                frequency[token] += 1
        texts = [[token for token in doc if frequency[token] > 500 and frequency[token] < 2000] for doc in doc_list]
        return texts

if __name__ == '__main__':
    gc = gd_compare('modelA')
    data = gc.compare(dic)
    print(data)



